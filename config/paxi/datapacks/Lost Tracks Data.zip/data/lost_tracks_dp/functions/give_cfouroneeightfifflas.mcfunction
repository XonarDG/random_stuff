execute at @s run summon item ~ ~ ~ {Item:{id:"supplementaries:music_disc_heave_ho", Count:1b, tag:{CustomModelData:6, HideFlags:32, display:{Lore:["\"\\u00a77C418 - Fifflas\""]}}}}
